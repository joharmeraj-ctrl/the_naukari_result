package com.example.the_naukari_result

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
