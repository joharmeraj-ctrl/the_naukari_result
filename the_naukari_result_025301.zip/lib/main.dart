import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const NaukriResultApp());
}

class NaukriResultApp extends StatefulWidget {
  const NaukriResultApp({super.key});

  @override
  State<NaukriResultApp> createState() => _NaukriResultAppState();
}

class _NaukriResultAppState extends State<NaukriResultApp> {
  Color _primaryColor = const Color(0xFF1E3A8A); // Default Blue

  void _changeThemeColor(Color newColor) {
    setState(() {
      _primaryColor = newColor;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'THE NAUKARI RESULT',
      theme: ThemeData(
        primaryColor: _primaryColor,
        useMaterial3: true,
      ),
      home: HomeScreen(
        primaryColor: _primaryColor,
        onColorChanged: _changeThemeColor,
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final Color primaryColor;
  final Function(Color) onColorChanged;

  const HomeScreen({
    super.key,
    required this.primaryColor,
    required this.onColorChanged,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  bool _isSearching = false;
  bool _isDarkMode = false;
  String _selectedThemeColorName = 'Blue';

  final TextEditingController _searchController = TextEditingController();

  final Map<String, String> categoryUrls = {
    'Latest Jobs': 'https://thenaukariresult.com/category/latest-jobs/',
    'Results': 'https://thenaukariresult.com/category/results/',
    'Admit Card': 'https://thenaukariresult.com/category/admit-card/',
    'Answer Key': 'https://thenaukariresult.com/category/answer-key/',
    'Syllabus': 'https://thenaukariresult.com/category/syllabus/',
    'Admission': 'https://thenaukariresult.com/category/admission/',
    'Counseling': 'https://thenaukariresult.com/category/counseling/',
    'Documents': 'https://thenaukariresult.com/category/documents/',
    'University Updates':
        'https://thenaukariresult.com/category/university-updates/',
    'Scholarship': 'https://thenaukariresult.com/category/scholarship/',
    'Govt Scheme': 'https://thenaukariresult.com/category/govt-scheme/',
  };

  Future<void> _launchURL(String urlString) async {
    final Uri url = Uri.parse(urlString);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $urlString');
    }
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      _buildHomeContent(),
      _buildCategoryContent(),
      _buildSavedContent(),
      _buildProfileContent(),
    ];

    return Scaffold(
      backgroundColor:
          _isDarkMode ? const Color(0xFF121212) : Colors.grey.shade100,
      appBar: AppBar(
        title: _isSearching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Search jobs, results...',
                  hintStyle: TextStyle(color: Colors.white70),
                  border: InputBorder.none,
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Text(
                    'THE NAUKARI RESULT',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 16),
                  ),
                  SizedBox(width: 4),
                  Icon(Icons.check_circle,
                      color: Colors.lightBlueAccent, size: 18),
                ],
              ),
        centerTitle: true,
        backgroundColor: widget.primaryColor,
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
        actions: [
          IconButton(
            icon: Icon(_isSearching ? Icons.close : Icons.search,
                color: Colors.white),
            onPressed: () {
              setState(() {
                _isSearching = !_isSearching;
                if (!_isSearching) {
                  _searchController.clear();
                }
              });
            },
          ),
          IconButton(
            icon: const Icon(Icons.notifications, color: Colors.amber),
            onPressed: () {},
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: widget.primaryColor,
        unselectedItemColor: Colors.grey.shade600,
        backgroundColor: _isDarkMode ? const Color(0xFF1E1E1E) : Colors.white,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(
              icon: Icon(Icons.category), label: 'Category'),
          BottomNavigationBarItem(icon: Icon(Icons.bookmark), label: 'Saved'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  // APP TOP HEADER STRIP
  Widget _buildTopNotificationBar() {
    String userName = "Meraj";
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
      color: const Color(0xFFE53935),
      child: Text(
        '🔥 Hello $userName, Welcome back to THE NAUKARI RESULT',
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
          fontSize: 13,
        ),
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  // TAB 1: HOME PAGE CONTENT
  Widget _buildHomeContent() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildTopNotificationBar(),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [widget.primaryColor, const Color(0xFF0F172A)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.15),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: const [
                  Text(
                    'Together We can succeed',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.amber,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'THE NAUKARI RESULT',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.0,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    '(Your trusted career information hub)',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 12,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.6,
              children: [
                _buildCategoryCard('Latest Jobs', Icons.work, Colors.brown),
                _buildCategoryCard(
                    'Results', Icons.emoji_events, Colors.amber.shade700),
                _buildCategoryCard(
                    'Admit Card', Icons.confirmation_number, Colors.orange),
                _buildCategoryCard('Answer Key', Icons.vpn_key, Colors.indigo),
                _buildCategoryCard('Syllabus', Icons.menu_book, Colors.blue),
                _buildCategoryCard('Admission', Icons.how_to_reg, Colors.red),
                _buildCategoryCard('Counseling', Icons.groups, Colors.teal),
                _buildCategoryCard(
                    'Documents', Icons.folder_shared, Colors.cyan.shade700),
                _buildCategoryCard(
                    'University Updates', Icons.school, Colors.black87),
                _buildCategoryCard(
                    'Scholarship', Icons.card_membership, Colors.green),
                _buildCategoryCard(
                    'Govt Scheme', Icons.account_balance, Colors.deepPurple),
              ],
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  // TAB 2: CATEGORY PAGE CONTENT
  Widget _buildCategoryContent() {
    return Column(
      children: [
        _buildTopNotificationBar(),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(
                'All Categories',
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: widget.primaryColor),
              ),
              const SizedBox(height: 12),
              ...categoryUrls.keys.map((title) {
                return Card(
                  color: _isDarkMode ? const Color(0xFF2C2C2C) : Colors.white,
                  margin: const EdgeInsets.only(bottom: 10),
                  elevation: 1,
                  child: ListTile(
                    leading:
                        Icon(Icons.label_important, color: widget.primaryColor),
                    title: Text(
                      title,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: _isDarkMode ? Colors.white : Colors.black87,
                      ),
                    ),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: () {
                      final targetUrl =
                          categoryUrls[title] ?? 'https://thenaukariresult.com';
                      _launchURL(targetUrl);
                    },
                  ),
                );
              }),
            ],
          ),
        ),
      ],
    );
  }

  // TAB 3: SAVED PAGE CONTENT
  Widget _buildSavedContent() {
    return Column(
      children: [
        _buildTopNotificationBar(),
        const Expanded(
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.bookmark_border, size: 64, color: Colors.grey),
                SizedBox(height: 12),
                Text(
                  'No Saved Items Yet',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey),
                ),
                SizedBox(height: 4),
                Text(
                  'Save updates to read them offline later',
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // TAB 4: PROFILE PAGE CONTENT (CUSTOMIZED BASED ON YOUR IMAGE)
  Widget _buildProfileContent() {
    Color cardBg = _isDarkMode ? const Color(0xFF1E1E1E) : Colors.white;
    Color textColor = _isDarkMode ? Colors.white : Colors.black87;

    return SingleChildScrollView(
      child: Column(
        children: [
          _buildTopNotificationBar(),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Profile Header Card
                Card(
                  color: cardBg,
                  elevation: 2,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 30,
                          backgroundColor: widget.primaryColor,
                          child: const Icon(Icons.person,
                              size: 36, color: Colors.white),
                        ),
                        const SizedBox(width: 16),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Meraj Johar',
                              style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: textColor),
                            ),
                            const SizedBox(height: 4),
                            const Text(
                              'Job & Exam Updates Aspirant',
                              style:
                                  TextStyle(color: Colors.grey, fontSize: 13),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Settings & Customization
                Text(
                  'Settings & Display',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: widget.primaryColor),
                ),
                const SizedBox(height: 8),
                Card(
                  color: cardBg,
                  elevation: 1,
                  child: Column(
                    children: [
                      ListTile(
                        leading:
                            Icon(Icons.language, color: widget.primaryColor),
                        title: Text('Change Language',
                            style: TextStyle(color: textColor)),
                        subtitle: const Text('English / Hindi'),
                        onTap: () {},
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading:
                            Icon(Icons.security, color: widget.primaryColor),
                        title: Text('App Permissions',
                            style: TextStyle(color: textColor)),
                        onTap: () {},
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: Icon(Icons.share_outlined,
                            color: widget.primaryColor),
                        title: Text('Refer A Friend',
                            style: TextStyle(color: textColor)),
                        onTap: () {},
                      ),
                      const Divider(height: 1),
                      // Theme Dark Mode Switch
                      SwitchListTile(
                        secondary: Icon(Icons.brightness_6,
                            color: widget.primaryColor),
                        title: Text('Theme Mode',
                            style: TextStyle(color: textColor)),
                        subtitle: Text(_isDarkMode ? 'Dark' : 'Light'),
                        value: _isDarkMode,
                        onChanged: (val) {
                          setState(() {
                            _isDarkMode = val;
                          });
                        },
                      ),
                      const Divider(height: 1),
                      // Dynamic Icon Color Selection
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16.0, vertical: 12.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.color_lens,
                                    color: widget.primaryColor),
                                const SizedBox(width: 16),
                                Text('Theme Color',
                                    style: TextStyle(
                                        color: textColor, fontSize: 15)),
                              ],
                            ),
                            Row(
                              children: [
                                _buildColorOption(
                                    'Blue', const Color(0xFF1E3A8A)),
                                const SizedBox(width: 8),
                                _buildColorOption('Purple', Colors.purple),
                                const SizedBox(width: 8),
                                _buildColorOption(
                                    'Green', Colors.green.shade700),
                                const SizedBox(width: 8),
                                _buildColorOption('Pink', Colors.pinkAccent),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Help Section (From Image)
                Text(
                  'Help & Support',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: widget.primaryColor),
                ),
                const SizedBox(height: 8),
                Card(
                  color: cardBg,
                  elevation: 1,
                  child: Column(
                    children: [
                      ListTile(
                        leading:
                            const Icon(Icons.rate_review, color: Colors.purple),
                        title: Text('Feedback',
                            style: TextStyle(color: textColor)),
                        onTap: () => _launchURL(
                            'https://thenaukariresult.com/contact-us/'),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.thumb_up, color: Colors.blue),
                        title:
                            Text('Rate Us', style: TextStyle(color: textColor)),
                        onTap: () {},
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading:
                            const Icon(Icons.headset_mic, color: Colors.teal),
                        title: Text('Contact Us',
                            style: TextStyle(color: textColor)),
                        onTap: () => _launchURL(
                            'https://thenaukariresult.com/contact-us/'),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.security_update_warning,
                            color: Colors.deepOrange),
                        title: Text('Cybercrime Reporting Portal',
                            style: TextStyle(color: textColor)),
                        onTap: () => _launchURL('https://cybercrime.gov.in/'),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading: const Icon(Icons.help_outline,
                            color: Colors.indigo),
                        title: Text('User Guide',
                            style: TextStyle(color: textColor)),
                        onTap: () => _launchURL(
                            'https://thenaukariresult.com/about-us/'),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading:
                            const Icon(Icons.phone_in_talk, color: Colors.red),
                        title: Text('National Cybercrime Helpline (1930)',
                            style: TextStyle(color: textColor)),
                        onTap: () => _launchURL('tel:1930'),
                      ),
                      const Divider(height: 1),
                      ListTile(
                        leading:
                            const Icon(Icons.location_on, color: Colors.amber),
                        title: Text('Locate Us',
                            style: TextStyle(color: textColor)),
                        onTap: () => _launchURL(
                            'https://thenaukariresult.com/contact-us/'),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 20),

                // Follow Us Section (Social Media Grid)
                Text(
                  'Follow Us',
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      color: widget.primaryColor),
                ),
                const SizedBox(height: 12),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildSocialIcon(
                        Icons.close, Colors.black, 'X', 'https://twitter.com'),
                    _buildSocialIcon(Icons.facebook, Colors.blue.shade800,
                        'Facebook', 'https://facebook.com'),
                    _buildSocialIcon(Icons.camera_alt, Colors.pink, 'Instagram',
                        'https://instagram.com'),
                    _buildSocialIcon(Icons.play_circle_fill, Colors.red,
                        'YouTube', 'https://youtube.com'),
                    _buildSocialIcon(Icons.work, Colors.blue.shade600,
                        'LinkedIn', 'https://linkedin.com'),
                    _buildSocialIcon(Icons.alternate_email, Colors.black,
                        'Threads', 'https://threads.net'),
                  ],
                ),

                const SizedBox(height: 24),

                // App Version & Info Footer
                Center(
                  child: Column(
                    children: [
                      Text(
                        'App Version: 1.0.0',
                        style: TextStyle(
                            color: Colors.grey.shade600, fontSize: 13),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        '© THE NAUKARI RESULT. All Rights Reserved.',
                        style: TextStyle(color: Colors.grey, fontSize: 11),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // COLOR PICKER WIDGET FOR PROFILE
  Widget _buildColorOption(String name, Color color) {
    bool isSelected = _selectedThemeColorName == name;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedThemeColorName = name;
        });
        widget.onColorChanged(color);
      },
      child: Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border:
              isSelected ? Border.all(color: Colors.black, width: 2.5) : null,
        ),
        child: isSelected
            ? const Icon(Icons.check, color: Colors.white, size: 16)
            : null,
      ),
    );
  }

  // SOCIAL ICON WIDGET
  Widget _buildSocialIcon(IconData icon, Color color, String name, String url) {
    return InkWell(
      onTap: () => _launchURL(url),
      borderRadius: BorderRadius.circular(30),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: color, size: 24),
      ),
    );
  }

  // DRAWER MENU
  Widget _buildDrawer() {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(
              color: widget.primaryColor,
            ),
            accountName: const Text(
              'THE NAUKARI RESULT',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            accountEmail: const Text('Your trusted career information hub'),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              child: ClipOval(
                child: Image.network(
                  'https://thenaukariresult.com/wp-content/uploads/2024/05/cropped-Favicon-192x192.png',
                  errorBuilder: (context, error, stackTrace) => Icon(
                    Icons.work,
                    size: 40,
                    color: widget.primaryColor,
                  ),
                ),
              ),
            ),
          ),
          ListTile(
            leading: Icon(Icons.home, color: widget.primaryColor),
            title: const Text('Home'),
            onTap: () {
              Navigator.pop(context);
              setState(() => _selectedIndex = 0);
            },
          ),
          ListTile(
            leading: const Icon(Icons.telegram, color: Colors.blue),
            title: const Text('Join Telegram Channel'),
            onTap: () {
              Navigator.pop(context);
              _launchURL('https://t.me/thenaukariresult');
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.info, color: Colors.grey),
            title: const Text('About Us'),
            onTap: () {
              Navigator.pop(context);
              _launchURL('https://thenaukariresult.com/about-us/');
            },
          ),
          ListTile(
            leading: const Icon(Icons.contact_support, color: Colors.grey),
            title: const Text('Contact Us'),
            onTap: () {
              Navigator.pop(context);
              _launchURL('https://thenaukariresult.com/contact-us/');
            },
          ),
          ListTile(
            leading: const Icon(Icons.privacy_tip, color: Colors.grey),
            title: const Text('Privacy Policy'),
            onTap: () {
              Navigator.pop(context);
              _launchURL('https://thenaukariresult.com/privacy-policy/');
            },
          ),
          ListTile(
            leading: const Icon(Icons.gavel, color: Colors.grey),
            title: const Text('Disclaimer'),
            onTap: () {
              Navigator.pop(context);
              _launchURL('https://thenaukariresult.com/disclaimer/');
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.share, color: Colors.green),
            title: const Text('Share App'),
            onTap: () => Navigator.pop(context),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryCard(String title, IconData icon, Color iconColor) {
    return Container(
      decoration: BoxDecoration(
        color: _isDarkMode ? const Color(0xFF2C2C2C) : Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
            color: _isDarkMode ? Colors.grey.shade800 : Colors.grey.shade300,
            width: 1),
      ),
      child: InkWell(
        onTap: () {
          final targetUrl =
              categoryUrls[title] ?? 'https://thenaukariresult.com';
          _launchURL(targetUrl);
        },
        borderRadius: BorderRadius.circular(8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 30, color: iconColor),
            const SizedBox(height: 6),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 13,
                color: _isDarkMode ? Colors.white : const Color(0xFF1E293B),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
